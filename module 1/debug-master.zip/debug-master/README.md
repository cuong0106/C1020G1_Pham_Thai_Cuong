# debug
Mã nguồn debug được sử dụng để thực hành tại [CodeGym](https://codegym.vn) 
